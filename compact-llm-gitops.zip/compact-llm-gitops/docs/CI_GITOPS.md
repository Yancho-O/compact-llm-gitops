# CI/CD and GitOps flow

## Build pipeline (GitLab CI)
Pipeline stages:
1. **lint**: ruff + black + mypy
2. **test**: pytest
3. **build**: docker build + push to GitLab container registry
4. **package**: helm lint
5. **gitops**: (optional) update image tags in the repo and push commit

## GitOps reconciliation (Argo CD)
Argo CD monitors the repo path:
- `deploy/kustomize/overlays/prod`

When `kustomization.yaml` image tags change, Argo CD applies the updated workload to the cluster.

## Recommended hardening for production
- split app repo and environment repo (separate permissions)
- sign images (cosign) and enforce policies
- use sealed secrets or external secret operator
- add OPA/Gatekeeper policies for resource, security, ingress constraints
