# Compact LLM / NLP Prototype + GitOps Deployment

This repository is an end-to-end, **compact transformer language model** prototype with:
- **Dataset preparation** (cleaning, tokenization, train/val split)
- **Training + experiment tracking** via **MLflow** (loss + perplexity)
- **Inference API** via **FastAPI**
- **Containerization** via Docker
- **Automated build/test** via **GitLab CI/CD**
- **Kubernetes deployment** using **Helm** and **Kustomize**
- **GitOps** deployment using **Argo CD**

## Repository layout

```
.
├── src/compact_llm/                # Python package (data prep, train, eval)
├── api/                            # FastAPI inference server
├── deploy/
│   ├── helm/compact-llm-api/        # Helm chart
│   └── kustomize/                  # Kustomize base + overlays
├── gitops/argocd/                  # Argo CD Application manifests
├── scripts/                        # Helper scripts (export model, bump image tag)
├── tests/                          # Unit tests
├── .gitlab-ci.yml                  # GitLab pipeline
└── pyproject.toml                  # Dependencies / tooling
```

---

## 1) Local development setup

### Prerequisites
- Python 3.10+
- Docker (for container build/run)
- (Optional) Kubernetes cluster + kubectl, Helm, Argo CD

### Create a virtualenv and install deps
```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e ".[dev]"
```

Run quality gates:
```bash
make lint
make test
```

---

## 2) Prepare dataset (cleaning + tokenization)

This project uses `datasets` to fetch a public text corpus. By default it uses `wikitext-2-raw-v1`,
but you can switch to any dataset/field.

```bash
python -m compact_llm.data.prep   --dataset wikitext   --config wikitext-2-raw-v1   --text-field text   --out-dir data/processed   --tokenizer-type bpe   --vocab-size 8000
```

Outputs:
- `data/processed/tokenizer/` (tokenizer files)
- `data/processed/train.jsonl` and `data/processed/val.jsonl`

---

## 3) Train a compact transformer + track experiments

Training uses a compact GPT-style model (few layers/heads, small embedding size) with Hugging Face
`transformers` and logs metrics to MLflow.

Start MLflow UI (local file-based tracking):
```bash
mlflow ui --backend-store-uri ./mlruns --port 5000
```

Train:
```bash
python -m compact_llm.train   --data-dir data/processed   --out-dir artifacts/model   --experiment compact-llm   --run-name gpt-mini   --max-steps 500   --batch-size 8   --seq-len 128
```

Key outcomes tracked:
- training loss
- eval loss
- eval perplexity

---

## 4) Evaluate (loss + perplexity)

```bash
python -m compact_llm.eval   --data-dir data/processed   --model-dir artifacts/model
```

---

## 5) Run inference API locally

Export (or simply point) the API at the trained model directory.

```bash
export MODEL_DIR=artifacts/model
uvicorn api.main:app --host 0.0.0.0 --port 8000
```

Generate:
```bash
curl -s http://localhost:8000/generate \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"Once upon a time", "max_new_tokens":64, "temperature":0.9}' | jq
```

---

## 6) Container build/run

```bash
docker build -t compact-llm-api:dev .
docker run --rm -p 8000:8000 -e MODEL_DIR=/model -v "$(pwd)/artifacts/model:/model" compact-llm-api:dev
```

---

## 7) Kubernetes deployment

### Option A: Helm
```bash
helm upgrade --install compact-llm-api deploy/helm/compact-llm-api \
  --namespace compact-llm --create-namespace \
  --set image.repository=YOUR_REGISTRY/compact-llm-api \
  --set image.tag=dev
```

### Option B: Kustomize
```bash
kubectl apply -k deploy/kustomize/overlays/dev
```

---

## 8) GitOps with Argo CD

Apply the Argo CD application manifest (points to the Kustomize overlay):
```bash
kubectl apply -n argocd -f gitops/argocd/compact-llm-api.yaml
```

Argo CD will continuously reconcile the Kubernetes state to match this repo.

---

## 9) GitLab CI/CD (build/test + GitOps bump)

`.gitlab-ci.yml` runs:
- lint + unit tests
- docker build + push
- helm lint
- (optional) a GitOps stage that updates the deployed image tag in the repo

See `.gitlab-ci.yml` and `scripts/bump_image_tag.py` for details.

---

## Notes
- This is a **prototype** intended to be small, reproducible, and easy to audit.
- For real workloads: enable GPU nodes, add caching, improve batching, and use proper secrets management.
