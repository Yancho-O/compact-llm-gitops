from __future__ import annotations

import os
from fastapi.testclient import TestClient

from api.main import app


def test_healthz_returns_json():
    client = TestClient(app)
    # Point to a non-existent model dir; health should still be JSON with status=error
    os.environ["MODEL_DIR"] = "/tmp/does-not-exist"
    r = client.get("/healthz")
    assert r.status_code == 200
    data = r.json()
    assert "status" in data
    assert "model_dir" in data


def test_generate_requires_model():
    client = TestClient(app)
    os.environ["MODEL_DIR"] = "/tmp/does-not-exist"
    r = client.post("/generate", json={"prompt": "Hello"})
    assert r.status_code == 500
