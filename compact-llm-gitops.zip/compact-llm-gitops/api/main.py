from __future__ import annotations

import os
from functools import lru_cache
from typing import Any, Dict, Optional

import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from transformers import AutoModelForCausalLM, AutoTokenizer


class GenerateRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=10_000)
    max_new_tokens: int = Field(64, ge=1, le=512)
    temperature: float = Field(0.9, gt=0.0, le=5.0)
    top_p: float = Field(0.95, gt=0.0, le=1.0)
    do_sample: bool = True


class GenerateResponse(BaseModel):
    prompt: str
    completion: str
    model_dir: str
    meta: Dict[str, Any]


app = FastAPI(title="Compact LLM Inference API", version="0.1.0")


@lru_cache(maxsize=1)
def _load_model_and_tokenizer(model_dir: str):
    if not os.path.isdir(model_dir):
        raise FileNotFoundError(f"MODEL_DIR does not exist: {model_dir}")

    tokenizer = AutoTokenizer.from_pretrained(model_dir, use_fast=True)
    model = AutoModelForCausalLM.from_pretrained(model_dir)

    # Prefer GPU if available; keep it simple and deterministic-ish for a prototype
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device)
    model.eval()
    return model, tokenizer, device


@app.get("/healthz")
def healthz() -> Dict[str, str]:
    model_dir = os.getenv("MODEL_DIR", "/model")
    try:
        _load_model_and_tokenizer(model_dir)
        return {"status": "ok", "model_dir": model_dir}
    except Exception as e:  # noqa: BLE001 - API health check
        return {"status": "error", "model_dir": model_dir, "detail": str(e)}


@app.post("/generate", response_model=GenerateResponse)
def generate(req: GenerateRequest) -> GenerateResponse:
    model_dir = os.getenv("MODEL_DIR", "/model")
    try:
        model, tokenizer, device = _load_model_and_tokenizer(model_dir)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(e)) from e

    inputs = tokenizer(req.prompt, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=req.max_new_tokens,
            temperature=req.temperature,
            top_p=req.top_p,
            do_sample=req.do_sample,
            pad_token_id=tokenizer.eos_token_id,
        )

    decoded = tokenizer.decode(out[0], skip_special_tokens=True)
    completion = decoded[len(req.prompt) :]
    return GenerateResponse(
        prompt=req.prompt,
        completion=completion,
        model_dir=model_dir,
        meta={
            "device": device,
            "max_new_tokens": req.max_new_tokens,
            "temperature": req.temperature,
            "top_p": req.top_p,
            "do_sample": req.do_sample,
        },
    )
