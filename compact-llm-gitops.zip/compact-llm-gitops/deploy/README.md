# Deployment Notes

This repo includes **both** Helm and Kustomize so you can demonstrate either packaging style.

- Helm chart: `deploy/helm/compact-llm-api`
- Kustomize: `deploy/kustomize/base` + overlays

The Kustomize base uses a simple `emptyDir` for `/model` (prototype only). In production, you would use:
- a PVC
- an initContainer that pulls model artifacts from object storage
- or bake a specific model artifact into the container image

Argo CD manifest: `gitops/argocd/compact-llm-api.yaml`
