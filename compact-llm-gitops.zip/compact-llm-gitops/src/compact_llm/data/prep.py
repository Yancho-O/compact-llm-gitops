from __future__ import annotations

import argparse
import json
import os
import re
from typing import Iterable, List, Tuple

from datasets import load_dataset
from tokenizers import ByteLevelBPETokenizer

from compact_llm.utils import ensure_dir


_WHITESPACE_RE = re.compile(r"\s+")


def normalize_text(x: str) -> str:
    x = x.replace("\u00a0", " ")
    x = _WHITESPACE_RE.sub(" ", x).strip()
    return x


def write_jsonl(path: str, rows: Iterable[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def iter_text(ds, text_field: str) -> Iterable[str]:
    for row in ds:
        if row.get(text_field) is None:
            continue
        t = normalize_text(str(row[text_field]))
        if t:
            yield t


def train_bpe_tokenizer(texts: List[str], out_dir: str, vocab_size: int) -> str:
    ensure_dir(out_dir)
    tmp_path = os.path.join(out_dir, "tokenizer_corpus.txt")
    with open(tmp_path, "w", encoding="utf-8") as f:
        for t in texts:
            f.write(t + "\n")

    tok = ByteLevelBPETokenizer()
    tok.train(files=[tmp_path], vocab_size=vocab_size, min_frequency=2, special_tokens=["<s>", "</s>", "<pad>", "<unk>"])
    tok.save_model(out_dir)

    # Create Hugging Face compatible tokenizer.json
    tok_json = os.path.join(out_dir, "tokenizer.json")
    tok.save(tok_json)

    # Cleanup large temp file
    try:
        os.remove(tmp_path)
    except OSError:
        pass

    return out_dir


def main() -> None:
    p = argparse.ArgumentParser(description="Prepare dataset: clean, split, train tokenizer, save JSONL.")
    p.add_argument("--dataset", default="wikitext", help="HF dataset name, e.g., wikitext")
    p.add_argument("--config", default="wikitext-2-raw-v1", help="HF dataset config name")
    p.add_argument("--text-field", default="text", help="Text field name")
    p.add_argument("--out-dir", default="data/processed", help="Output directory")
    p.add_argument("--tokenizer-type", choices=["bpe"], default="bpe")
    p.add_argument("--vocab-size", type=int, default=8000)
    p.add_argument("--max-train-rows", type=int, default=50000, help="Cap tokenizer training corpus size for speed")
    args = p.parse_args()

    ensure_dir(args.out_dir)
    tok_dir = os.path.join(args.out_dir, "tokenizer")

    ds = load_dataset(args.dataset, args.config)
    train_split = ds["train"]
    val_split = ds["validation"] if "validation" in ds else ds["test"]

    # Build tokenizer corpus
    corpus = []
    for i, t in enumerate(iter_text(train_split, args.text_field)):
        corpus.append(t)
        if i + 1 >= args.max_train_rows:
            break

    train_bpe_tokenizer(corpus, tok_dir, args.vocab_size)

    # Save normalized JSONL
    train_rows = ({"text": t} for t in iter_text(train_split, args.text_field))
    val_rows = ({"text": t} for t in iter_text(val_split, args.text_field))

    write_jsonl(os.path.join(args.out_dir, "train.jsonl"), train_rows)
    write_jsonl(os.path.join(args.out_dir, "val.jsonl"), val_rows)

    print(f"Wrote: {os.path.join(args.out_dir, 'train.jsonl')}")
    print(f"Wrote: {os.path.join(args.out_dir, 'val.jsonl')}")
    print(f"Tokenizer: {tok_dir}")


if __name__ == "__main__":
    main()
