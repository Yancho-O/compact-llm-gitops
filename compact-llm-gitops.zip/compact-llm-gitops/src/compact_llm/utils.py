from __future__ import annotations

import math
import os
from dataclasses import dataclass
from typing import Dict, Iterable, List

import numpy as np


def set_seed(seed: int) -> None:
    import random

    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except Exception:
        pass


def perplexity_from_loss(loss: float) -> float:
    # ppl = exp(loss)
    return float(math.exp(loss))


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)
