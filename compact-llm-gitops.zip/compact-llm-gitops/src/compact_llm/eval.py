from __future__ import annotations

import argparse
import math
import os
from typing import List

import numpy as np
import torch
from datasets import Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, DataCollatorForLanguageModeling, Trainer, TrainingArguments

from compact_llm.train import read_jsonl_texts, tokenize_dataset
from compact_llm.utils import perplexity_from_loss


def main() -> None:
    p = argparse.ArgumentParser(description="Evaluate a trained compact model (loss + perplexity).")
    p.add_argument("--data-dir", default="data/processed")
    p.add_argument("--model-dir", default="artifacts/model")
    p.add_argument("--seq-len", type=int, default=128)
    p.add_argument("--batch-size", type=int, default=8)
    args = p.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model_dir, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(args.model_dir)
    if torch.cuda.is_available():
        model = model.cuda()

    val_texts = read_jsonl_texts(os.path.join(args.data_dir, "val.jsonl"))
    val_ds = tokenize_dataset(val_texts, tokenizer, args.seq_len)
    data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

    args_tr = TrainingArguments(
        output_dir=os.path.join(args.model_dir, "eval_tmp"),
        per_device_eval_batch_size=args.batch_size,
        report_to=[],
    )

    trainer = Trainer(model=model, args=args_tr, eval_dataset=val_ds, data_collator=data_collator)
    metrics = trainer.evaluate()
    loss = float(metrics.get("eval_loss", np.nan))
    ppl = perplexity_from_loss(loss) if np.isfinite(loss) else np.nan

    print({"eval_loss": loss, "eval_perplexity": ppl})


if __name__ == "__main__":
    main()
