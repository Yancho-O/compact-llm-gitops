from __future__ import annotations

import argparse
import os
from dataclasses import asdict, dataclass
from typing import Dict, List, Optional

import mlflow
import numpy as np
import torch
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    DataCollatorForLanguageModeling,
    GPT2Config,
    GPT2LMHeadModel,
    Trainer,
    TrainingArguments,
)

from compact_llm.utils import ensure_dir, perplexity_from_loss, set_seed


def read_jsonl_texts(path: str) -> List[str]:
    import json

    out: List[str] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line)["text"])
    return out


@dataclass(frozen=True)
class ModelSpec:
    n_layer: int = 4
    n_head: int = 4
    n_embd: int = 256
    n_positions: int = 256


def build_model(tokenizer, spec: ModelSpec) -> GPT2LMHeadModel:
    cfg = GPT2Config(
        vocab_size=len(tokenizer),
        n_layer=spec.n_layer,
        n_head=spec.n_head,
        n_embd=spec.n_embd,
        n_positions=spec.n_positions,
        bos_token_id=tokenizer.convert_tokens_to_ids("<s>") if "<s>" in tokenizer.get_vocab() else tokenizer.bos_token_id,
        eos_token_id=tokenizer.convert_tokens_to_ids("</s>") if "</s>" in tokenizer.get_vocab() else tokenizer.eos_token_id,
        pad_token_id=tokenizer.convert_tokens_to_ids("<pad>") if "<pad>" in tokenizer.get_vocab() else tokenizer.eos_token_id,
    )
    return GPT2LMHeadModel(cfg)


def tokenize_dataset(texts: List[str], tokenizer, seq_len: int) -> Dataset:
    # Tokenize each sample, then pack by concatenating and chunking into fixed blocks.
    enc = tokenizer(texts, add_special_tokens=True, truncation=False)
    input_ids = []
    for ids in enc["input_ids"]:
        input_ids.extend(ids)

    # Drop remainder
    total_len = (len(input_ids) // seq_len) * seq_len
    input_ids = input_ids[:total_len]

    blocks = [input_ids[i : i + seq_len] for i in range(0, total_len, seq_len)]
    return Dataset.from_dict({"input_ids": blocks})


def compute_metrics(eval_pred):
    # Trainer already logs eval_loss. We add perplexity.
    logits, labels = eval_pred
    # We cannot reliably compute loss here without model; use eval_loss from Trainer callback.
    return {}


def main() -> None:
    p = argparse.ArgumentParser(description="Train a compact GPT-style model with MLflow tracking.")
    p.add_argument("--data-dir", default="data/processed", help="Directory with train.jsonl, val.jsonl, tokenizer/")
    p.add_argument("--out-dir", default="artifacts/model", help="Where to save the trained model")
    p.add_argument("--experiment", default="compact-llm", help="MLflow experiment name")
    p.add_argument("--run-name", default="gpt-mini", help="MLflow run name")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--seq-len", type=int, default=128)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--learning-rate", type=float, default=5e-4)
    p.add_argument("--max-steps", type=int, default=500)
    p.add_argument("--eval-steps", type=int, default=100)
    p.add_argument("--save-steps", type=int, default=250)
    p.add_argument("--warmup-steps", type=int, default=50)

    # Model spec knobs
    p.add_argument("--n-layer", type=int, default=4)
    p.add_argument("--n-head", type=int, default=4)
    p.add_argument("--n-embd", type=int, default=256)
    p.add_argument("--n-positions", type=int, default=256)
    args = p.parse_args()

    set_seed(args.seed)
    ensure_dir(args.out_dir)

    tok_dir = os.path.join(args.data_dir, "tokenizer")
    tokenizer = AutoTokenizer.from_pretrained(tok_dir, use_fast=True)

    # Ensure pad token set
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_texts = read_jsonl_texts(os.path.join(args.data_dir, "train.jsonl"))
    val_texts = read_jsonl_texts(os.path.join(args.data_dir, "val.jsonl"))

    train_ds = tokenize_dataset(train_texts, tokenizer, args.seq_len)
    val_ds = tokenize_dataset(val_texts, tokenizer, args.seq_len)

    spec = ModelSpec(n_layer=args.n_layer, n_head=args.n_head, n_embd=args.n_embd, n_positions=args.n_positions)
    model = build_model(tokenizer, spec)

    data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

    training_args = TrainingArguments(
        output_dir=os.path.join(args.out_dir, "checkpoints"),
        overwrite_output_dir=True,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        max_steps=args.max_steps,
        evaluation_strategy="steps",
        eval_steps=args.eval_steps,
        save_strategy="steps",
        save_steps=args.save_steps,
        warmup_steps=args.warmup_steps,
        logging_steps=20,
        report_to=[],  # we log to MLflow manually for transparency
        fp16=torch.cuda.is_available(),
    )

    mlflow.set_tracking_uri(os.getenv("MLFLOW_TRACKING_URI", "file:./mlruns"))
    mlflow.set_experiment(args.experiment)

    with mlflow.start_run(run_name=args.run_name):
        mlflow.log_params(
            {
                "seed": args.seed,
                "seq_len": args.seq_len,
                "batch_size": args.batch_size,
                "learning_rate": args.learning_rate,
                "max_steps": args.max_steps,
                "eval_steps": args.eval_steps,
                "save_steps": args.save_steps,
                "warmup_steps": args.warmup_steps,
                **asdict(spec),
                "vocab_size": len(tokenizer),
            }
        )

        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=train_ds,
            eval_dataset=val_ds,
            data_collator=data_collator,
            compute_metrics=compute_metrics,
        )

        trainer.train()

        eval_metrics = trainer.evaluate()
        eval_loss = float(eval_metrics.get("eval_loss", np.nan))
        mlflow.log_metrics(
            {
                "eval_loss": eval_loss,
                "eval_perplexity": perplexity_from_loss(eval_loss) if np.isfinite(eval_loss) else np.nan,
            }
        )

        # Save final model + tokenizer to out-dir root (API expects this layout)
        trainer.model.save_pretrained(args.out_dir)
        tokenizer.save_pretrained(args.out_dir)

        # Log artifact to MLflow (model directory)
        mlflow.log_artifacts(args.out_dir, artifact_path="model")

        print(f"Saved model to: {args.out_dir}")
        print(f"Eval loss: {eval_loss:.4f}  perplexity: {perplexity_from_loss(eval_loss):.2f}")


if __name__ == "__main__":
    main()
