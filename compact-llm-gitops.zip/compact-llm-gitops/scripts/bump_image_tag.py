from __future__ import annotations

import argparse
import re
from pathlib import Path

import yaml


def bump_helm_values(image_tag: str) -> None:
    values_path = Path("deploy/helm/compact-llm-api/values.yaml")
    data = yaml.safe_load(values_path.read_text(encoding="utf-8"))
    data.setdefault("image", {})
    data["image"]["tag"] = image_tag
    values_path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


def bump_kustomize_image(image_tag: str) -> None:
    k_path = Path("deploy/kustomize/overlays/prod/kustomization.yaml")
    y = yaml.safe_load(k_path.read_text(encoding="utf-8"))
    images = y.get("images", [])
    if not images:
        images = [{"name": "compact-llm-api", "newName": "compact-llm-api", "newTag": image_tag}]
    else:
        for img in images:
            if img.get("name") in ("compact-llm-api", "ghcr.io/example/compact-llm-api"):
                img["newTag"] = image_tag
    y["images"] = images
    k_path.write_text(yaml.safe_dump(y, sort_keys=False), encoding="utf-8")


def main() -> None:
    p = argparse.ArgumentParser(description="Bump image tag in Helm values and Kustomize overlay (GitOps).")
    p.add_argument("--image-tag", required=True)
    args = p.parse_args()

    bump_helm_values(args.image_tag)
    bump_kustomize_image(args.image_tag)
    print(f"Bumped image tag to {args.image_tag}")


if __name__ == "__main__":
    main()
