from __future__ import annotations

import argparse
import os
import shutil

import mlflow


def main() -> None:
    p = argparse.ArgumentParser(description="Export the latest MLflow run's model artifact to a target dir.")
    p.add_argument("--experiment", default="compact-llm")
    p.add_argument("--artifact-path", default="model")
    p.add_argument("--out-dir", default="artifacts/model")
    args = p.parse_args()

    client = mlflow.tracking.MlflowClient()
    exps = [e for e in client.search_experiments() if e.name == args.experiment]
    if not exps:
        raise SystemExit(f"Experiment not found: {args.experiment}")
    exp_id = exps[0].experiment_id

    runs = client.search_runs([exp_id], order_by=["attributes.start_time DESC"], max_results=1)
    if not runs:
        raise SystemExit("No runs found.")
    run = runs[0]
    run_id = run.info.run_id

    # Download artifacts
    dst = args.out_dir
    if os.path.exists(dst):
        shutil.rmtree(dst)
    os.makedirs(dst, exist_ok=True)

    local_path = client.download_artifacts(run_id, args.artifact_path, dst)
    # download_artifacts nests; move contents to dst root if needed
    if os.path.isdir(local_path) and local_path != dst:
        for name in os.listdir(local_path):
            shutil.move(os.path.join(local_path, name), os.path.join(dst, name))

    print(f"Exported run {run_id} artifacts to: {dst}")


if __name__ == "__main__":
    main()
